<template>
    <div>
        <div class="form-group">
            <router-link to="/product" class="btn btn-default">Back</router-link>
        </div>

        <div class="panel panel-default">
            <div class="panel-heading">Edit product</div>
            <div class="panel-body">
                <form v-on:submit="saveForm()">
                    <div class="row">
                        <div class="col-xs-12 form-group">
                            <label class="control-label">Product company name</label>
                            <select v-model="product.company_id" id="companies" class="form-control" style="width: 30%">
                                <option selected>Choose</option>
                            </select>
                            <!--<input type="text" v-model="product.company.name" class="form-control">-->
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12 form-group">
                            <label class="control-label">Product name</label>
                            <input type="text" v-model="product.name" class="form-control">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12 form-group">
                            <label class="control-label">Product address</label>
                            <input type="text" v-model="product.address" class="form-control">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12 form-group">
                            <label class="control-label">Product website</label>
                            <input type="text" v-model="product.website" class="form-control">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12 form-group">
                            <label class="control-label">Product email</label>
                            <input type="text" v-model="product.email" class="form-control">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12 form-group">
                            <button class="btn btn-success">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        mounted() {
            let app = this;
            let id = app.$route.params.id;
            app.productId = id;
            axios.get('/api/v1/products/' + id)
                .then(function (resp) {
                    app.product = resp.data;
                })
                .catch(function () {
                    alert("Could not load your product")
                });

            axios.get('/api/v1/companies/')
                .then(function (resp) {
                    $.each(resp.data, function(index, item) {
                        $('#companies').append(
                            $('<option></option>').val(item.id).html(item.name)
                        );
                    });
                })
                .catch(function () {
                    alert("Could not load your companies")
                });
        },
        data: function () {
            return {
                productId: null,
                product: {
                    company_id: '',
                    name: '',
                    address: '',
                    website: '',
                    email: ''
                }
            }
        },
        methods: {
            saveForm() {
                var app = this;
                var newproduct = app.product;
                axios.patch('/api/v1/products/' + app.productId, newproduct)
                    .then(function (resp) {
                        app.$router.replace('/product');
                    })
                    .catch(function (resp) {
                        console.log(resp);
                        alert("Could not create your product burası");
                    });
            }
        }
    }
</script>