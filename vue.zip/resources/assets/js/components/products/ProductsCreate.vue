<template>
    <div>
        <div class="form-group">
            <router-link to="/product" class="btn btn-default">Back</router-link>
        </div>

        <div class="panel panel-default">
            <div class="panel-heading">Create new product</div>
            <div class="panel-body">
                <form v-on:submit="saveForm()">
                    <div class="row">
                        <div class="col-xs-12 form-group">
                            <label class="control-label">product company_id</label>
                            <select v-model="product.company_id" id="companies" name="companies" class="form-control" style="width: 30%">
                                <option selected>Choose</option>
                            </select>
                            <!--<input type="text" v-model="product.company_id" class="form-control">-->
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12 form-group">
                            <label class="control-label">product name</label>
                            <input type="text" v-model="product.name" class="form-control">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12 form-group">
                            <label class="control-label">product address</label>
                            <input type="text" v-model="product.address" class="form-control">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12 form-group">
                            <label class="control-label">product website</label>
                            <input type="text" v-model="product.website" class="form-control">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12 form-group">
                            <label class="control-label">product email</label>
                            <input type="text" v-model="product.email" class="form-control">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12 form-group">
                            <button class="btn btn-success">Create</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data: function () {
            return {
                product: {
                    company_id: '',
                    name: '',
                    address: '',
                    website: '',
                    email: ''
                }
            }
        },
        mounted() {
            axios.get('/api/v1/companies/')
                .then(function (resp) {
                    $.each(resp.data, function(index, item) {
                        $('#companies').append(
                            $('<option></option>').val(item.id).html(item.name)
                        );
                    });
                })
                .catch(function () {
                    alert("Could not load your companies")
                });
        },
        methods: {
            saveForm() {
                event.preventDefault();
                var app = this;
                var newproduct = app.product;
                axios.post('/api/v1/products', newproduct)
                    .then(function (resp) {
                        app.$router.push({path: '/product'});
                    })
                    .catch(function (resp) {
                        console.log(resp);
                        alert("Could not create your product");
                    });
            }
        }
    }
</script>
