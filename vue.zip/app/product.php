<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class product extends Model
{
    protected $fillable = ['company_id', 'name', 'address', 'website', 'email'];

    protected $table = 'products';

    public function company()
    {
        return $this->belongsTo(company::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
